#!/bin/bash
# 定义变量
APNIC_URL="http://ftp.apnic.net/stats/apnic/delegated-apnic-latest"
IPV4_FILE="/etc/nginx/conf/ipv4.txt"      
TEMP_IPV4="/tmp/ipv4_temp.txt"
NGINX_BIN="nginx"

echo "========== 开始更新 Nginx 中国 IP 库 =========="

# 1. 下载最新的 APNIC 数据
wget -q -O /tmp/delegated-apnic-latest "$APNIC_URL"
if [ $? -ne 0 ]; then
	    echo "下载失败，请检查网络连接！"
	        exit 1
fi

# 2. 提取中国 IP 段并转换为 Nginx geo 格式 (IP段 1;)
echo "[1/4] 提取 IPv4 网段..."
cat /tmp/delegated-apnic-latest | awk -F'|' '$0 ~ /CN/ && $0 ~ /ipv4/ {print $4 "/" 32-log($5)/log(2) " 1;"}' > "$TEMP_IPV4"

# 3. 校验提取的数据是否有效（防止下载空文件导致误拦截所有流量）
if [ ! -s "$TEMP_IPV4" ]; then
	    echo "提取的 IPv4 数据为空，终止更新！"
	        exit 1
fi

# 4. 原子替换文件并平滑重载 Nginx
echo "[3/4] 替换 IP 库文件..."
mv -f "$TEMP_IPV4" "$IPV4_FILE"

echo "[4/4] 测试并重载 Nginx..."
$NGINX_BIN -t
if [ $? -eq 0 ]; then
	    $NGINX_BIN -s reload
	        echo "========== 更新成功并已生效 =========="
	else
		    echo "Nginx 配置测试失败，请手动检查！"
		        exit 1
fi
